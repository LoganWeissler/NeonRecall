const SAMPLE_QUESTIONS = [
  { prompt: "What port is used by FTP control?", answer: "21", options: ["20", "21", "22", "23", "24"] },
  { prompt: "Which port does SSH use by default?", answer: "22", options: ["20", "21", "22", "23", "25"] },
  { prompt: "What is the default port for HTTPS?", answer: "443", options: ["80", "110", "143", "443", "445"] },
  { prompt: "Which port is commonly used by DNS?", answer: "53", options: ["21", "25", "53", "67", "69"] },
  { prompt: "What port is used by SMTP?", answer: "25", options: ["21", "22", "23", "25", "53"] },
  { prompt: "True or false: HTTP commonly uses port 80.", answer: "True", options: ["True", "False"] },
  { prompt: "Which protocol secures web traffic with TLS?", answer: "HTTPS", options: ["HTTP", "HTTPS", "FTP", "SMTP", "SNMP"] },
  { prompt: "What port is used by POP3 by default?", answer: "110", options: ["80", "110", "123", "143", "161"] },
  { prompt: "What port does IMAP use by default?", answer: "143", options: ["110", "123", "135", "143", "161"] },
  { prompt: "True or false: SSH traffic is encrypted.", answer: "True", options: ["True", "False"] },
  { prompt: "Which port is used by Remote Desktop Protocol?", answer: "3389", options: ["3306", "3389", "3390", "5432", "5900"] },
  { prompt: "What service commonly uses port 67?", answer: "DHCP", options: ["DNS", "DHCP", "FTP", "NTP", "SNMP"] },
  { prompt: "Which port is commonly used by NTP?", answer: "123", options: ["110", "123", "143", "161", "389"] },
  { prompt: "True or false: Telnet sends data without encryption.", answer: "True", options: ["True", "False"] },
  { prompt: "Which secure protocol replaced Telnet for remote shells?", answer: "SSH", options: ["FTP", "HTTP", "RDP", "SSH", "TFTP"] },
];

const FALL_START = 30;
const IMPACT_LINE = 82;
const vendorUrl = (fileName) => new URL(`../vendor/${fileName}`, import.meta.url).href;
const refs = Object.fromEntries([
  "game-shell", "score", "progress-count", "progress-fill", "streak", "multiplier", "hearts", "timer",
  "question-pod", "question-number", "question-text", "feedback", "speed", "answers", "import-modal",
  "import-button", "close-import", "file-input", "file-label", "ocr-progress", "ocr-icon", "ocr-status",
  "ocr-bar", "source-text", "import-error", "generate-button", "mute-button", "end-screen", "end-icon",
  "end-eyebrow", "end-title", "final-score", "final-streak", "restart-button", "new-notes-button",
].map((id) => [id, document.getElementById(id)]));

const state = {
  questions: SAMPLE_QUESTIONS,
  index: 0,
  score: 1250,
  lives: 3,
  streak: 4,
  multiplier: 1.5,
  speed: 1,
  status: "playing",
  muted: false,
  disabled: new Set(),
  startTime: performance.now(),
  frame: 0,
  locked: false,
  modalOpen: false,
};

const shuffle = (items) => [...items].sort(() => Math.random() - 0.5);
const cleanText = (value) => value.replace(/\r/g, " ").replace(/[\t ]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
const titleCase = (value) => value.trim().replace(/^[•\-*\d.)\s]+/, "").replace(/\b\w/g, (letter) => letter.toUpperCase());

function numberOptions(answer) {
  const number = Number(answer);
  return shuffle([...new Set([number - 2, number - 1, number, number + 1, number + 2].filter((item) => item >= 0).map(String))]);
}

function wordOptions(answer, answerPool) {
  const matches = answerPool.filter((item) => item !== answer && !/^\d+$/.test(item));
  const fallbacks = ["Not stated", "None of these", "Both A and B", "Unknown"];
  return shuffle([answer, ...shuffle([...new Set([...matches, ...fallbacks])]).slice(0, 4)]);
}

function buildQuestions(sourceText) {
  const text = cleanText(sourceText);
  const lines = text.split(/\n|(?<=[.!?])\s+/).map((line) => line.trim()).filter((line) => line.length > 7);
  const facts = [];

  lines.forEach((line) => {
    const normalized = line.replace(/[.!?]+$/, "").trim();
    let match = normalized.match(/^(.{2,48}?)\s+(?:uses|runs on|operates on|is assigned to)\s+(?:TCP\/?UDP\s+)?(?:port\s*)?(\d{1,5})$/i);
    if (match) {
      facts.push({ subject: titleCase(match[1]), answer: match[2], type: "port" });
      return;
    }
    match = normalized.match(/^(?:port\s*)?(\d{1,5})\s+(?:is used by|belongs to|is assigned to)\s+(.{2,48})$/i);
    if (match) {
      facts.push({ subject: titleCase(match[2]), answer: match[1], type: "port" });
      return;
    }
    match = normalized.match(/^(.{2,46}?)\s*[:=—-]\s*(.{1,48})$/);
    if (match && match[1].split(" ").length < 8 && match[2].split(" ").length < 9) {
      facts.push({ subject: titleCase(match[1]), answer: match[2].trim(), type: /^\d+$/.test(match[2].trim()) ? "port" : "fact" });
      return;
    }
    match = normalized.match(/^(.{2,50}?)\s+is\s+(.{2,60})$/i);
    if (match && match[1].split(" ").length < 9 && match[2].split(" ").length < 12) {
      facts.push({ subject: titleCase(match[1]), answer: match[2].trim(), type: "fact" });
    }
  });

  const answerPool = facts.map((fact) => fact.answer);
  const questions = facts.map((fact) => ({
    prompt: fact.type === "port" ? `What port is used by ${fact.subject}?` : `What is associated with ${fact.subject}?`,
    answer: fact.answer,
    options: /^\d+$/.test(fact.answer) ? numberOptions(fact.answer) : wordOptions(fact.answer, answerPool),
  }));

  const factualLines = lines.filter((line) => line.split(" ").length >= 5 && line.split(" ").length <= 24);
  factualLines.forEach((line, index) => {
    if (questions.length >= 15) return;
    const statement = line.replace(/[.!?]+$/, "");
    const shouldBeFalse = index % 3 === 2 && /\d+/.test(statement);
    const displayStatement = shouldBeFalse ? statement.replace(/\d+/, (value) => String(Number(value) + 1)) : statement;
    questions.push({ prompt: `True or false: ${displayStatement}.`, answer: shouldBeFalse ? "False" : "True", options: shuffle(["True", "False"]) });
  });

  if (questions.length < 3) return [];
  const original = [...questions];
  while (questions.length < 15) questions.push({ ...original[questions.length % original.length] });
  return shuffle(questions).slice(0, 15);
}

function icon(name, className = "") {
  return `<i data-lucide="${name}"${className ? ` class="${className}"` : ""}></i>`;
}

function refreshIcons() {
  if (window.lucide) window.lucide.createIcons({ attrs: { "stroke-width": 2 } });
}

function renderHud() {
  refs.score.textContent = state.score.toLocaleString();
  refs["progress-count"].textContent = `${Math.min(state.index, 15)}/15`;
  refs["progress-fill"].style.width = `${(Math.min(state.index, 15) / 15) * 100}%`;
  refs.streak.textContent = `Streak ${state.streak}`;
  refs.multiplier.textContent = `${state.multiplier.toFixed(1)}×`;
  refs.speed.textContent = `${state.speed.toFixed(2)}×`;
  refs.hearts.setAttribute("aria-label", `${state.lives} lives remaining`);
  refs.hearts.innerHTML = [0, 1, 2].map((item) => icon("heart", item < state.lives ? "heart-live" : "heart-empty")).join("");
  refreshIcons();
}

function renderQuestion() {
  const question = state.questions[state.index % state.questions.length];
  refs["question-number"].textContent = `Question ${String(state.index + 1).padStart(2, "0")}`;
  refs["question-text"].textContent = question.prompt;
  refs.answers.className = `answers answers-${Math.min(question.options.length, 5)}`;
  refs.answers.innerHTML = question.options.map((option, index) => `
    <button type="button" data-answer="${encodeURIComponent(option)}">
      <kbd>${index + 1}</kbd><span></span>
    </button>
  `).join("");
  [...refs.answers.querySelectorAll("button")].forEach((button, index) => {
    button.querySelector("span").textContent = question.options[index];
    button.addEventListener("click", () => answerQuestion(question.options[index]));
  });
  state.disabled.clear();
}

function setFeedback(type, text) {
  refs.feedback.hidden = !text;
  refs.feedback.className = `feedback feedback-${type}`;
  refs.feedback.textContent = text || "";
}

function playTone(kind) {
  if (state.muted) return;
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  state.audio = state.audio || new AudioContext();
  const oscillator = state.audio.createOscillator();
  const gain = state.audio.createGain();
  oscillator.type = kind === "correct" ? "sine" : kind === "impact" ? "sawtooth" : "square";
  oscillator.frequency.setValueAtTime(kind === "correct" ? 660 : kind === "impact" ? 90 : 180, state.audio.currentTime);
  oscillator.frequency.exponentialRampToValueAtTime(kind === "correct" ? 980 : 50, state.audio.currentTime + 0.18);
  gain.gain.setValueAtTime(0.08, state.audio.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, state.audio.currentTime + 0.22);
  oscillator.connect(gain).connect(state.audio.destination);
  oscillator.start();
  oscillator.stop(state.audio.currentTime + 0.23);
}

function startQuestion() {
  cancelAnimationFrame(state.frame);
  state.locked = false;
  state.startTime = performance.now();
  refs["question-pod"].hidden = false;
  refs["question-pod"].classList.remove("is-correct");
  refs["question-pod"].style.top = `${FALL_START}%`;
  setFeedback("", "");
  renderQuestion();
  renderHud();
  state.frame = requestAnimationFrame(tick);
}

function tick(now) {
  if (state.status !== "playing" || state.modalOpen || state.locked) return;
  const duration = Math.max(3700, 10000 / state.speed);
  const elapsed = now - state.startTime;
  const ratio = Math.min(1, elapsed / duration);
  const position = FALL_START + (IMPACT_LINE - FALL_START) * ratio;
  refs["question-pod"].style.top = `${position}%`;
  refs.timer.textContent = `${Math.max(0, Math.ceil((1 - ratio) * (10 / state.speed)))}s`;
  if (ratio >= 1) {
    handleImpact();
    return;
  }
  state.frame = requestAnimationFrame(tick);
}

function answerQuestion(option) {
  if (state.locked || state.status !== "playing" || state.disabled.has(option)) return;
  const question = state.questions[state.index % state.questions.length];
  const button = [...refs.answers.querySelectorAll("button")].find((item) => decodeURIComponent(item.dataset.answer) === option);
  if (option === question.answer) {
    state.locked = true;
    state.streak += 1;
    state.multiplier = Math.min(5, 1 + Math.floor(state.streak / 3) * 0.5);
    state.score += Math.round(200 * state.multiplier);
    button?.classList.add("answer-correct");
    refs["question-pod"].classList.add("is-correct");
    setFeedback("correct", `LOCKED IN +${Math.round(200 * state.multiplier)}`);
    playTone("correct");
    renderHud();
    window.setTimeout(() => {
      state.index += 1;
      if (state.index >= 15) showEnd("won");
      else startQuestion();
    }, 600);
  } else {
    state.disabled.add(option);
    button?.classList.add("answer-disabled");
    if (button) button.disabled = true;
    state.streak = 0;
    state.multiplier = 1;
    state.speed = Math.min(2.25, state.speed + 0.12);
    setFeedback("wrong", "MISS — DESCENT ACCELERATED");
    playTone("wrong");
    renderHud();
    window.setTimeout(() => setFeedback("", ""), 650);
  }
}

function handleImpact() {
  if (state.locked || state.status !== "playing") return;
  state.locked = true;
  state.lives = Math.max(0, state.lives - 1);
  state.streak = 0;
  state.multiplier = 1;
  state.speed = Math.min(2.25, state.speed + 0.16);
  refs["game-shell"].classList.add("is-impacting");
  setFeedback("impact", "BASE HIT — LIFE LOST");
  playTone("impact");
  renderHud();
  window.setTimeout(() => {
    refs["game-shell"].classList.remove("is-impacting");
    if (state.lives <= 0) showEnd("lost");
    else {
      state.index += 1;
      if (state.index >= 15) showEnd("won");
      else startQuestion();
    }
  }, 700);
}

function showEnd(result) {
  cancelAnimationFrame(state.frame);
  state.status = result;
  refs["end-screen"].hidden = false;
  refs["final-score"].textContent = state.score.toLocaleString();
  refs["final-streak"].textContent = state.streak;
  refs["end-icon"].className = `end-icon ${result}`;
  refs["end-icon"].innerHTML = result === "won" ? icon("book-open-text") : icon("zap");
  refs["end-eyebrow"].textContent = result === "won" ? "Level secured" : "Defense core offline";
  refs["end-title"].textContent = result === "won" ? "Memory defended." : "The city needs another run.";
  refreshIcons();
}

function restart() {
  state.index = 0;
  state.score = 0;
  state.lives = 3;
  state.streak = 0;
  state.multiplier = 1;
  state.speed = 1;
  state.status = "playing";
  state.locked = false;
  refs["end-screen"].hidden = true;
  closeImporter();
  startQuestion();
}

function openImporter() {
  state.modalOpen = true;
  cancelAnimationFrame(state.frame);
  refs["import-modal"].hidden = false;
  window.setTimeout(() => refs["source-text"].focus(), 30);
}

function closeImporter() {
  state.modalOpen = false;
  refs["import-modal"].hidden = true;
  if (state.status === "playing") {
    state.startTime = performance.now();
    state.frame = requestAnimationFrame(tick);
  }
}

function showImportError(message = "") {
  refs["import-error"].hidden = !message;
  refs["import-error"].textContent = message;
}

function setOcrProgress(status, progress = 0, done = false) {
  refs["ocr-progress"].hidden = false;
  refs["ocr-status"].textContent = status;
  refs["ocr-bar"].style.width = `${Math.round(progress * 100)}%`;
  const statusRow = refs["ocr-progress"].querySelector("span");
  const existingIcon = statusRow.querySelector("svg, i");
  if (existingIcon) existingIcon.outerHTML = icon(done ? "check" : "loader-circle", done ? "" : "spin");
  refreshIcons();
}

async function readFile(file) {
  if (!file) return;
  refs["file-label"].textContent = file.name;
  showImportError();
  if (file.type.startsWith("text/") || /\.(txt|md|csv)$/i.test(file.name)) {
    refs["source-text"].value = await file.text();
    refs["generate-button"].disabled = !refs["source-text"].value.trim();
    setOcrProgress("Text file ready", 1, true);
    return;
  }
  if (!file.type.startsWith("image/")) {
    showImportError("Please upload a PNG, JPG, WEBP, TXT, MD, or CSV file.");
    return;
  }
  if (!window.Tesseract) {
    showImportError("The local OCR engine did not load. Paste the notes instead.");
    return;
  }
  try {
    setOcrProgress("Loading OCR engine…", 0);
    const worker = await window.Tesseract.createWorker("eng", 1, {
      workerPath: vendorUrl("tesseract-worker.min.js"),
      corePath: vendorUrl("tesseract-core-simd-lstm.wasm.js"),
      langPath: new URL("../vendor", import.meta.url).href,
      gzip: false,
      logger: (message) => {
        if (message.status) setOcrProgress(message.status.replace(/^./, (letter) => letter.toUpperCase()), message.progress || 0);
      },
    });
    const result = await worker.recognize(file);
    await worker.terminate();
    refs["source-text"].value = result.data.text.trim();
    refs["generate-button"].disabled = !refs["source-text"].value;
    setOcrProgress("Photo transcribed", 1, true);
  } catch (error) {
    console.error(error);
    showImportError("OCR could not read that image. Try a clearer photo or paste the notes instead.");
    refs["ocr-progress"].hidden = true;
  }
}

refs["import-button"].addEventListener("click", openImporter);
refs["close-import"].addEventListener("click", closeImporter);
refs["import-modal"].addEventListener("mousedown", (event) => {
  if (event.target === refs["import-modal"]) closeImporter();
});
refs["file-input"].addEventListener("change", (event) => readFile(event.target.files?.[0]));
refs["source-text"].addEventListener("input", () => {
  refs["generate-button"].disabled = !refs["source-text"].value.trim();
  showImportError();
});
refs["generate-button"].addEventListener("click", () => {
  const generated = buildQuestions(refs["source-text"].value);
  if (!generated.length) {
    showImportError("Add at least three clear facts or sentences. A format like “FTP uses port 21” works especially well.");
    return;
  }
  state.questions = generated;
  restart();
});
refs["mute-button"].addEventListener("click", () => {
  state.muted = !state.muted;
  refs["mute-button"].innerHTML = `${icon(state.muted ? "volume-x" : "volume-2")} M`;
  refs["mute-button"].title = state.muted ? "Unmute (M)" : "Mute (M)";
  refs["mute-button"].setAttribute("aria-label", state.muted ? "Unmute" : "Mute");
  refreshIcons();
});
refs["restart-button"].addEventListener("click", restart);
refs["new-notes-button"].addEventListener("click", () => {
  refs["end-screen"].hidden = true;
  openImporter();
});

window.addEventListener("keydown", (event) => {
  if (event.key.toLowerCase() === "m") refs["mute-button"].click();
  if (event.key.toLowerCase() === "i") openImporter();
  if (event.key === "Escape" && state.modalOpen) closeImporter();
  const optionIndex = Number(event.key) - 1;
  const question = state.questions[state.index % state.questions.length];
  if (!state.modalOpen && optionIndex >= 0 && optionIndex < question.options.length) answerQuestion(question.options[optionIndex]);
});

refreshIcons();
renderHud();
startQuestion();
