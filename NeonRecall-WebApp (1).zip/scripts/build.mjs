import { cpSync, mkdirSync, rmSync } from "node:fs";

const output = new URL("../dist/", import.meta.url);
rmSync(output, { recursive: true, force: true });
mkdirSync(output, { recursive: true });

for (const item of ["index.html", "src", "assets", "vendor"]) {
  const source = new URL(`../${item}`, import.meta.url);
  const target = new URL(`../dist/${item}`, import.meta.url);
  cpSync(source, target, { recursive: true });
}

console.log("Built dependency-free site in dist/");
